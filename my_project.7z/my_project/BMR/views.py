from asyncio import ProactorEventLoop
from queue import PriorityQueue
from django.shortcuts import render
from django import forms
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.urls import reverse

# Create your views here.

class NewTaskForm(forms.Form):
    task = forms.CharField(label = "название")
    radio = forms.NullBooleanField(

        widget=forms.Select(
            label = "выбери пол",
            choices=[
                (True,'man')    #FIXME: problem with tumple
                (False,'Woman')
            ]
        )
    )




form = NewTaskForm()
def add(request):
    if request.method == "POST":
        form = NewTaskForm(request.POST)
        if form.is_valid():
            task = form.cleaned_data["task"]
            BMR.append(task)
            return HttpResponseRedirect(reverse("BMR:index"))
        else:
            print("форма не валидна")
            return HttpResponseRedirect(reverse("BMR:index"))
    else: 
        return render(
            request,
            "BMR/add.html",
            {"form": NewTaskForm()}
        )

def index(request):
    return render(
            request,
            "BMR/index.html",
            {"form": NewTaskForm()}
        )