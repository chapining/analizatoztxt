from asyncio import ProactorEventLoop
from queue import PriorityQueue
from django.shortcuts import render
from django import forms
from django.http import HttpResponseRedirect
from django.urls import reverse

# Create your views here.
def index(reqest):
    tasks = ["первое", "второе", "третье"]
    return render(
        reqest,
        "tasks/index.html",
        {"tasks": tasks}
    )

class NewTaskForm(forms.Form):
    task = forms.CharField(
        label = "название"
    )





form = NewTaskForm()
def add(request):
    if request.method == "POST":
        form = NewTaskForm(request.POST)
        if form.is_valid():
            task = form.cleaned_data["task"]
            tasks.append(task)
            return HttpResponseRedirect(reverse("tasks:index"))
        else:
            print("форма не валидна")
            return HttpResponseRedirect(reverse("tasks:index"))
    else: 
        return render(
            request,
            "tasks/add.html",
            {"form": NewRaskForm()}
        )